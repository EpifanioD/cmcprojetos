<?php

echo get_company_logo($estimate_info->company_id, "estimate");
