<?php

echo company_widget($invoice_info->company_id, "invoice");
