<?php

echo get_company_logo($order_info->company_id, "order");
